var app=angular.module('App', ['ngMaterial']);



console.log($('#ex19').slider());

var myList = [
  { "Feedback": "Data Visibility of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "User Experience of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "Usage of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "Data Quality of the App?", "que":["Wrong product is selected","Delay in delivery"]},
  { "Feedback": "Performance of the App?", "que":["Wrong product is selected","Delay in delivery"]}
];

app.controller('demoController', function($scope,$http,$timeout) {
  $scope.myList = [
    { "Feedback": "Data Visibility of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "User Experience of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "Usage of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "Data Quality of the App?", "que":["Wrong product is selected","Delay in delivery"]},
    { "Feedback": "Performance of the App?", "que":["Wrong product is selected","Delay in delivery"]}
  ];
$scope.result=[];

$( document ).ready(function() {

    var i=0;
  angular.forEach($scope.myList, function(obj){
    // console.log($('#ex'+i).data('slider').getValue());
    $('#ex'+i).slider().on('change', function(event) {
      console.log("asdf");
      var j=0;
      angular.forEach($scope.myList, function(obj){
        document.getElementById("newcheckex"+j).style.display="none";
        j++;
      });

       var newVal = this.value;
       var id=this.id;
       console.log(id);
       var thenum = id.replace( /^\D+/g, '');
       console.log(thenum);
       if (newVal<=3) {
         document.getElementById("newcheck"+id).style.display="";

       }
       else {
         document.getElementById("newcheck"+id).style.display="none";
       }
    });
    i++;
    });
  });
$scope.sendData = function(){
  console.log("asjdgajsgd");
  var i=0;
angular.forEach($scope.myList, function(obj){
var feedback={};
feedback.que=obj.Feedback;
feedback.rating=document.getElementById("ex"+i).value;
feedback.checkinput=[];
var j=0;
angular.forEach(obj.que, function(a){
if (document.getElementById(obj.Feedback+j).checked==true) {
feedback.checkinput.push(obj.que[j]);
}
  j++;
});

i++;
console.log(feedback);
});

}

console.log($scope.myList);

});
